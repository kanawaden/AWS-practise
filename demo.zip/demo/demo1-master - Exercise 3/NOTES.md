Added aws_s3_bucket_policy to access bucket from vpc only.
