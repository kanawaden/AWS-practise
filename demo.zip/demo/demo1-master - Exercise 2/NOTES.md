Create alarm - Done
Create SNS topic -Done

This task is incomplete, please use below url to complete
Ref: https://aws.amazon.com/premiumsupport/knowledge-center/automatic-recovery-ec2-cloudwatch/
