1. Created a s3 bucket named "artifacts_bucket".
2. Added aws s3 cp command in local provisioner.
