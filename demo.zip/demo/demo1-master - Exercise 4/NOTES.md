Create a lambda function which will copy file from S3 to ec2 instance. In ec2 instance, it will replace the html file.
